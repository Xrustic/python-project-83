# python-project-83
### Hexlet tests and linter status:
[![Actions Status](https://github.com/Xrustic/python-project-83/workflows/hexlet-check/badge.svg)](https://github.com/Xrustic/python-project-83/actions)
### Ссылка на домен с результатом:
[![https://python-project-83-20ur.onrender.com](https://python-project-83-20ur.onrender.com)]